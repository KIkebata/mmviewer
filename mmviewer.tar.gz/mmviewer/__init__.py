#!/usr/bin/env python3
from __version__ import __version__

__copyright__ = 'Copyright (C) 2022 Kengo Ikebata'
__license__ = 'GPLv3'
__author__ = 'Kengo Ikebata'
__author_email__ = 'kikebata623@gmail.com'
__url__ = 'https://github.com/KIkebata/mmviewer'
